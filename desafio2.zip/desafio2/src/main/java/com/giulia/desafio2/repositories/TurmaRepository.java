package com.giulia.desafio2.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.giulia.desafio2.entities.Turma;

public interface TurmaRepository extends JpaRepository<Turma, Long>{

}
