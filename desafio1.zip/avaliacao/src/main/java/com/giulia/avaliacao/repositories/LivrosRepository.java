package com.giulia.avaliacao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.giulia.avaliacao.entities.Livros;

public interface LivrosRepository extends JpaRepository<Livros, Long>{

}
