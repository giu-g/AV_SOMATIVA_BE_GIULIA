package com.giulia.avaliacao.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.giulia.avaliacao.entities.Livros;
import com.giulia.avaliacao.repositories.LivrosRepository;

@Service
public class LivrosService {
	
	@Autowired
	private LivrosRepository livrosRepository;
	
	public List<Livros> getAllLivros() {
		return livrosRepository.findAll();
	}

	public Livros getLivrosById(long id) {
		return livrosRepository.findById(id).orElse(null);
	}

	public Livros saveLivros(Livros livros) {
		return livrosRepository.save(livros);
	}

}
