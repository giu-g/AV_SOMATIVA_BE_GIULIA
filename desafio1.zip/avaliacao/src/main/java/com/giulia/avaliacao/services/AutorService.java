package com.giulia.avaliacao.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.giulia.avaliacao.entities.Autor;
import com.giulia.avaliacao.repositories.AutorRepository;

@Service
public class AutorService {
	
	@Autowired
	private AutorRepository autorRepository;
	
	public List<Autor> getAllAutor() {
		return autorRepository.findAll();
	}

	public Autor getAutorById(long id) {
		return autorRepository.findById(id).orElse(null);
	}

	public Autor saveAutor(Autor autor) {
		return autorRepository.save(autor);
	}

}
