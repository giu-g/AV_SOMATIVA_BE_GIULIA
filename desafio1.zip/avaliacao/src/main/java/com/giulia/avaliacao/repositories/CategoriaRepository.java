package com.giulia.avaliacao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.giulia.avaliacao.entities.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long>{

}
